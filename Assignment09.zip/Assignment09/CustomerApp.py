#-------------------------------------------------#
# Title: CustomerApp
# Dev:   KCreek
# Date:  12/15/2018
# Desc: This application manages Customer Data
# ChangeLog: KCreek, 12/15/2018, RevNew
#
#-------------------------------------------------#

if __name__ == "__main__":
    import Persons, Customers, DataProcess
else:
    raise Exception("This File was not meant to be imported")

#-- Data --# 

# Empty List to hold the additional Customers 
NewCustList = []
# Create a File Path to Assign Path 
strFilePath = "C:\\_PythonClass\\Assignment09\\Customers.txt"
# Instantiate a Data Processor Object 
objProcessor = DataProcess.DataProcess(strFilePath)
# Create an Instance of the Customer List Object to Hold Customer
custList = Customers.CustomerList()

#-- Processing --#
# Function To Save Data to File
while True:
    # Obtain the User Choice for the Menu
    intUserChoice = objProcessor.UserInput()
    # Case Option to add new Customer 
    if intUserChoice == 1:
        objNewCustomer = objProcessor.CreateNewCustomer()
        NewCustList.append(objNewCustomer)
    # Case Option to Save View Customer List    
    elif intUserChoice == 2:
        objProcessor.ReadFile()
    # Case option to Save Changes to File
    elif intUserChoice ==3:
        objProcessor.FileSave(NewCustList)
    # Case Option to exit program
    elif intUserChoice == 4:
        break
    # Case Option where option is out of Range     
    else:
        print("That is out of the Range of Options")



# Create an Instance of the Data Processor Class

