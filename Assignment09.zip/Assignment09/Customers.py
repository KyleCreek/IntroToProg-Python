#------------Customers.py Module ---------------#
# Desc: Class that holds personal Data
# Dev: Kyle Creek
# Date: 12/13/2018
# ChangeLog: 12/13, Class Developed, KCreek
#---------------------------------------------#

# Raise an exception if the person class is run as Main
if __name__ == "__main__":
    raise Exception("This file is not meant to be run by itsef")

# Import Persons Parent Class 
import Persons

# Make Child Class from Person Class object 
class Customer(Persons.Person):
    """ Class for Customer Data """
    #-------------------------------------#
    # Desc: Customer Data
    # Dev: KCreek
    # Date: 12/13/2018
    # ChangeLog: 12/13, Class Developed, KCreek
    #-------------------------------------#

    # Fields

    # Constructor 
    def __init__(self, FirstName, LastName, ID = None):
        # Attributes borrowed from parent class 
        super().__init__(FirstName, LastName)
        # Customer ID 
        self.__ID = ID
  

    # Properties
    # Customer ID
    @property
    def ID(self):
        return self.__ID
    
    @ID.setter
    def ID(self, Value):
        self.__ID = Value
    
class CustomerList(object):
    """ Class for List Customer Data """
    #-------------------------------------#
    # Desc: Manages a List of Customers 
    # Dev: KCreek
    # Date: 12/13/2018
    # ChangeLog: 12/13, Class Developed, KCreek
    #-------------------------------------#

    # Fields
    # A list To Hold Customer Objects
    __lstCustomers = []


    # Constructor 
    def __init__(self):
        pass
    
    # Methods 
    @staticmethod
    def AddCustomer(Customer):
        ''' Method to Add Customers to Customer List '''
        if(str(Customer.__class__) == "<class 'Customers.Customer'>"):
            CustomerList.__lstCustomers.append(Customer)
        else:
            raise Exception("Only Customer Objects can be added to this list")

    @staticmethod
    def ToString():
        """ Explicitly Returns Field Data """
        for item in CustomerList.__lstCustomers:
            print(str(item.FirstName + " " + item.LastName + "\n"))

# End of Class 

