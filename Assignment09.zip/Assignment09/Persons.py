#------------Persons.py Module ---------------#
# Desc: Class that holds personal Data
# Dev: Kyle Creek
# Date: 12/13/2018
# ChangeLog: 12/13, Class Developed, KCreek
#---------------------------------------------#

# Raise an exception if the person class is run as Main
if __name__ == "__main__":
    raise Exception("This file is not meant to be run by itsef")

# Make The Class
class Person(object):
    """ Base Class for Personal Data """
    #-------------------------------------#
    # Desc: Holds Personal Data
    # Dev: KCreek
    # Date: 12/13/2018
    # ChangeLog: 12/13, Class Developed, KCreek
    #-------------------------------------#

    # Fields

    # Constructor 
    def __init__(self, FirstName = "", LastName = ""):
        # Attributes
        self.__FirstName = FirstName
        self.__LastName = LastName

    # Properties
    # FirstName
    @property
    def FirstName(self):
        return self.__FirstName
    
    @FirstName.setter
    def FirstName(self, Value):
        self.__FirstName = Value
    
    #Last Name
    @property
    def LastName(self):
        return self.__LastName
    
    @LastName.setter
    def LastName(self, Value):
        self.__LastName = Value

    # Method
    def SayHello(self):
        print("Hi, My name is " + self.FirstName + " " + self.LastName)


# End of Class 

