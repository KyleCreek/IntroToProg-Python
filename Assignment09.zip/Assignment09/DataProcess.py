#------------DataProcess.py Module ---------------#
# Desc: Class that Can Process Customer Data 
# Dev: Kyle Creek
# Date: 12/15/2018
# ChangeLog: 12/13, Class Developed, KCreek
#---------------------------------------------#

# Raise an exception if the person class is run as Main
if __name__ == "__main__":
    raise Exception("This file is not meant to be run by itsef")

import Customers 

class DataProcess(object):
    """ Class for Processing Customer Data """
    #-------------------------------------#
    # Desc: Customer Data Processor
    # Dev: KCreek
    # Date: 12/15/2018
    # ChangeLog: 12/15, Class Developed, KCreek
    #-------------------------------------#

    # Constructor 
    def __init__(self, FileName = None):
        self.__FileName = FileName

    # Customer ID
    @property
    def FileName(self):
        return self.__FileName
    
    @FileName.setter
    def FileName(self, Value):
        self.__FileName = Value

    # Method
    def UserInput(self):
        ''' Function to Obtain UserInput '''
        
        print('''
        Select from the List of Available Options:
        1: Add New Customer
        2: View Customer List  
        3: Save New Customer to List
        4: Exit Program''')
        
        try:
            intUserInput = int(input("Please Chose an Action To Execute: "))
        except ValueError:
            print("That is not an acceptable input, Please Try again")
        return intUserInput

    def IDMaker(self):
        ''' Method to Determine the Customer ID '''
        fileObj = open(self.__FileName, 'r')
        for line in fileObj:
            textlist = line.split(",")
            IDMake = int(textlist[0])
            IDMake += 1
        return IDMake    

    def CreateNewCustomer(self):
        ''' Function to Create a Customer and Store into Customer List '''
        try:
            strFirstName = str(input("Provide Customer First Name: ")).title()
            strLastName = str(input("Provide Customer Last Name: ")).title()
            # Create a Customer Object
            objCust = Customers.Customer(strFirstName, strLastName)
            ID = DataProcess.IDMaker(self)
            objCust.ID = ID
            # Add New Customer to the Customer List 
            Customers.CustomerList.AddCustomer(objCust)
            objCust.SayHello()
        except Exception as e:
            print(e)
        return objCust

    def ReadFile(self):
        ''' Method to Read CustomerList File '''
        fileObj = open(self.FileName, 'r')
        for line in fileObj:
            textlist = line.split(",")
            print("ID: ", textlist[0], "First Name: ", textlist[1], "Last Name: ", textlist[2])
        fileObj.close()

    def FileSave(self, lstInput):
        ''' Method to Save New Information to File ''' 
        fileObj = open(self.FileName, "a")
        for objects in lstInput:
            text = str(objects.ID) + "," + str(objects.FirstName) + "," + str(objects.LastName + "\n")
            fileObj.write(text)
            fileObj.close()
# End of Class 



