#
# Title: A Simple To Do List and Classes
# Date: Nov 22, 2018
# Change Log:
#   KCreek, 11/22/2018, Script Created
#


# Define To Do List Class
class ToDo(object):
  
    """ Function to Display Menu Options to User """
    def menuview(self):
        # Prints available options to the user
        print('''
        Please Select an action to perform from the list below:
        1. Show Current "To Do" List
        2. Add new item to "To Do" List
        3. Remove an Existing Item from "To Do" List
        4. Save Changes to "To Do" List
        5. Exit Program ''')
    
    """ Function Written to put the file lines into a list of dicitonaries """
    def loadingTaskList(self, filename):
        # Create file object given the filename in the 'read' modde
        fileObj = open(filename, 'r')
        # Creates an empty task list to store the dictionaries in each line
        tasklist = []
        # 'for' loop to process each line in provided file
        for line in fileObj:
            # Empty Dictionary to store information
            dictionary = {}
            # Create list with 'split()' function for later processing
            x = line.split(",")
            # Assign variable 'task' by slicing list 'x'
            task = x[0].strip()
            # Assign variable 'priority' by slicing list 'x'
            priority = x[1].strip()
            # Assigning 'task' and 'value' to empty dictionary
            dictionary[task] = priority
            # Appeds 'tasklist' with new dictionary
            tasklist.append(dictionary)
        return tasklist

    """ Function written to Obtain User Input for menu options """
    def userInput(self):
        # Establish 'while' loop until acceptable input is obtained
        while True:
            # 'try-except' loop to ensure user provides integer value
            try:
                # Obtain user input
                userInput = int(input("Please a menu option: "))
                break
            except (ValueError):
                # Alert user their provided response is not acceptable
                print("That is not an Acceptable input")
        return userInput 

    """ Function Written to display tasks to users """
    def taskview(self, listinput):
        # Assigns variable 'linenumber' for display purposes
        linenumber = 0
        # Outer 'for' loop to process each line in the provided list
        for line in listinput:
            # Use of 'items()' dictionary method to parse keys and values in inner 'for' loop
            for key, value in line.items():
                # Assign key to variable 'key'
                key = key
                # Assign value to variable 'value'
                value = value
            # Displays user "To Do" list in a friendly format
            print("Task Number: ", linenumber, "\tName: ", key, "\tPriority: ", value)
            # Adds to variable 'linenumber' for outer 'for' loop
            linenumber += 1

    """ Funtion Written to Add Item to list/table """
    def additem(self, listinput):
        # Establish empty dicitonary to store provided values
        dictadd = {}
        # Obtains user inpput for the name of the task
        task = input("Please Provide Task Name: ")
        # 'While' loop written to run until acceptable input is obtained
        while True:
            # 'try-except' written to ensure user input is acceptable
            try:
                # Display to user available priorities to assign to task
                print(""" Please Select Task Priority
                1 : Low
                2: Medium
                3: High """)
                # Obtain the user input for priority to relate to provided task
                priority = int(input("Please select a priority option: "))

                # Case statement where priority is 'Low'
                if priority == 1:
                    # Adds task and associated priority to empty dictionary
                    dictadd[task] = "Low"
                    # Appends list with new dictionary
                    listinput.append(dictadd)
                    break
                # Case statement where priority is 'Medium'
                elif priority == 2:
                    # Adds task and associated priority to empty dictionary
                    dictadd[task] = 'Medium'
                    # Appends list with new dictionary
                    listinput.append(dictadd)
                    break
                # Case statement where priority is 'High'
                elif priority == 3:
                    # Adds task and associated priority to empty dictionary
                    dictadd[task] = 'High'
                    # Appends list with new dictionary
                    listinput.append(dictadd)
                    break
                # Case Statement where user input is out of range
                else:
                    print("That is out of the range of options")
           # Error handler to ensure user has provided integer and program does not break
            except ValueError:
                print("That is not an acceptable option")
        return listinput

    """ Function Written to Remoe an item from the list/table """
    def deleteitem(self, listinput):
        # 'while' loop written until acceptable input is obtained
        while True:
            # 'try-except' error handling to ensure user input is acceptable
            try:
                # Calls on 'ToDo' classes 'taskview()' method and passes provided list
                ToDo.taskview(listinput)
                # Obtain user's choice for what item they would like to delete
                userChoice = int(input("Select an option to delete:" ))
                # Delete's users provided option 
                del listinput[userChoice]
                break
            # Exception handling statement where incorrect Value is provided or provided
            # input is out of index range
            except (ValueError, IndexError):
                print("That is not an acceptable option")

    """Function Written to  Save tasks to the 'ToDo.txt' file """
    def filesave(self, filename, listinput):
        # Creates 'fileObj' object based on the provided file in the 'write' mode
        fileObj = open(filename, 'w')
        # Outer 'for' loop to process each dicitonary within the provided list
        for line in listinput:
            # Use of 'items()' dictionary method to parse keys and value in inner 'for' loop
            for key, value in line.items():
                # Assign key to variable 'key'
                key = key
                # Assign value to variable 'value'
                value = value
                # Create text string with 'key' and 'value', separated by a ','
                # returns to new line and stores in variable 'text'
                text = str(key) + "," + str(value) + "\n"
            # Writes text string to the file object "fileObj"
            fileObj.write(text)
        # Closes file object "fileObj"
        fileObj.close()
        

# Main Program Loop 

# Assign file name to variable 'filename'
filename = "C:\\_PythonClass\\Assignment06\\ToDo.txt"
# Establish Class instance
ToDo = ToDo()

# Stores dictionaries in a list for Further Processing
returnlist = ToDo.loadingTaskList(filename)

# Diplays the 'To Do' List to the user
print('\nWelcome User, Here is your Current "To Do" List: ')
ToDo.taskview(returnlist)

# Loop operation for users to select task
while True:
    # Show menu options to the user
    ToDo.menuview()
    # Obtain the user input to direct to desired menu option
    userInput = ToDo.userInput()
    # Case Option to display "To Do" List to User
    if userInput == 1:
        ToDo.taskview(returnlist)
    # Case option to add item to "To Do" List
    elif userInput == 2:
        ToDo.additem(returnlist)
    # Case option to remove item from "To Do" List
    elif userInput == 3:
        ToDo.deleteitem(returnlist)
    # Case option to save changes to "To Do" List
    elif userInput == 4:
        ToDo.filesave(filename, returnlist)
    # Case option to exit the program
    elif userInput == 5:
        break
    # Case option where user input is out of range
    else:
        print('The provided input is out of the range of available options')

input("Press 'Enter' to exit the Program")


    