import pickle

''' Class Created to obtain the user information '''
class userCheck(object):
    ''' Function Created to Obtain the User Name for Verification ''' 
    def userName(self):
        userName = input("Provide your User Name: ")
        userName = userName.strip()
        userName = userName.lower()
        return userName
    ''' Function Created to Load Authorized Users to be checked against Username '''
    def userLoad(self, filename):
        returnlist = []
        with open(filename, "rb") as f:
            while True:
                try:
                    returnlist.append(pickle.load(f))
                except EOFError:
                    break
        return returnlist

''' Class to create a confidence league user '''
class Survivor(object):
    ''' Instantiate file directories based on the user name passed to the class when class is instantiated ''' 
    def __init__(self,name):
        self.filename = "C:\\_PythonClass\\Assignment07\\ConfidenceLeague\\Users\\"+ name
        self.pickedfile = "C:\\_PythonClass\\Assignment07\\ConfidenceLeague\\Users\\" + name + "\\pickedTeams.dat"
        self.unpickedfile = "C:\\_PythonClass\\Assignment07\\ConfidenceLeague\\Users\\" + name + "\\unpickedTeams.dat"
    ''' Method to Load Pickled Files ''' 
    def pickleLoad(self, filename):
        returnlist = []
        with open(filename, "rb") as f:
            while True:
                try:
                    returnlist.append(pickle.load(f))
                except EOFError:
                    break
        return returnlist
    ''' Method to Save pickled files '''
    def picklesave(self, filein, listin):
        objFile = open(filein,"wb")
        for item in listin:
            pickle.dump(item, objFile)
        objFile.close()  
    '''Method to Make List from pickled data '''
    def listmaker(self, datain):
        emptylist = []
        for line in datain:
            emptylist.append(line)
        return emptylist    
    ''' Method to Display the List of Options ''' 
    def listview(self, listin):
        linenumber = 0
        for line in listin:
            print("Option Number: ", linenumber, "Team: ", line.title())
            linenumber += 1
    ''' Method to Pick a team for the Week '''
    def teamChoose(self, listin):
        while True:
            try:
                confidenceuser.listview(listin)
                userChoice = int(input("Please Select a team from the list for the week: "))
                teampick = listin[userChoice]
                break
            except (ValueError, IndexError):
                print("That is not an acceptable Option")
        return teampick   
    ''' Method to Query for Save input ''' 
    def saveInput(self):
        while True:
            print('''
            Are you Sure you would like to save?
            1: Yes
            2: No ''')

            try:
                choiceInput = int(input("Provide Save Option : "))
                if choiceInput == 1:
                    break
                elif choiceInput == 2:
                    break
                else:
                    print('That is not within the Range of Options')
            except ValueError:
                print("That is not an acceptable input ")
        return choiceInput  
    '''Method  to append lists based on the team picked and the save option '''
    def pickAppend(self, listin, listout, pick):
        for item in listin:
            if item == pick:
                listout.append(pick)
            else:
                pass
        return listout
    ''' Method to Remove the pick that was chosen and place it in another list ''' 
    def pickRemove(self, listin, listout):
        for item in listin:
            if item in listout:
                listout.remove(item)
            else:
                pass
        return listout

# --- main ---

# Assign variable to the user name file containing all the users in the league 
usersFile = "C:\\_PythonClass\\Assignment07\\rawUsers.dat"
# Instantiate userCheck Class
userCheck = userCheck()
# Un-Pickle the data file containing all users in the league with the 'pickleLoad' function and load to list
usersList = userCheck.userLoad(usersFile)
# Query user for their user name 
user = userCheck.userName()

# if-else loop created to verify the user logging in is actually a member of the league
if user in usersList:
    # Given the user is authorized, a flag is set to true for the ensuing 'while' loop.
    # Additionally, a instance of the Survivor class is instantiated and variables
    # are assigned from the classes "init" method based on the provided user name. 
    flag = True
    confidenceuser = Survivor(user)
    filename = confidenceuser.filename
    pickedfile = confidenceuser.pickedfile
    unpickedfile = confidenceuser.unpickedfile
    
    # Using the pickle load function to un-pickle the data of teams that have and have not been selected and sort into list
    pickedList = confidenceuser.pickleLoad(pickedfile)
    unpickedList = confidenceuser.pickleLoad(unpickedfile)

# No data is passed if the user is not in the league and the program will end
else:
    print('Access is not Granted')
    flag = False

# 'while' loop that can only be entered if the user is in the authorized list of users 
while flag == True:
    # Display lost of options to the user
    print('''
    1: View Chosen Teams
    2: View Unchosen Teams
    3: Choose Team for Week
    4: Save User Choice
    5: Exit Program
    ''')
    try:
        # Establish input so user can determine what action they would like to take. 
        userChoice = int(input("Provide input option: "))
        # Print Teams that have been chosen to the screen
        if userChoice == 1:
            print("Here are the Teams that Have been Chosen: ")
            confidenceuser.listview(pickedList)
        
        # Print Teams that Have not been chosen to the screen
        elif userChoice == 2:
            print("Here are the teams that have NOT been Chosen: ")
            confidenceuser.listview(unpickedList)
        
        # Chose a team for the week using the 'teamChoose' method.
        elif userChoice == 3:
            print("Please Choose a team for the week: ")
            teampick = confidenceuser.teamChoose(unpickedList)
            print("You have chosen the ", teampick.title())

        # Save User Choice for weekly pick
        elif userChoice == 4:
            choiceInput = confidenceuser.saveInput()
            if choiceInput == 1:
                pickedList = confidenceuser.pickAppend(unpickedList, pickedList,teampick)
                unpickedList = confidenceuser.pickRemove(pickedList, unpickedList)
                print("Hre is the new picked team List: ", pickedList)
                print("Here is the new unpicked team list: ", unpickedList)
                # Save new picked team
                confidenceuser.picklesave(pickedfile, pickedList)
                confidenceuser.picklesave(unpickedfile, unpickedList)
            if choiceInput == 2:
                pass
        # Case option to exit program 
        elif userChoice == 5:
            break

        # Case option where user provides input that is out of range of acceptable choices 
        else: 
            print("That is out of Range of the Acceptable Options ")
    
    # Exception clause where the user provides a string
    except ValueError:
        print("That is not an Acceptable Option ")

input("Press 'Enter' To exit the program")
