# Import Pickle Module
import pickle

# Define a class to generate data for Confidence League 
class DataGenerator(object):
    ''' Generator to Establish Variable Names at Class Instantiation '''
    def __init__(self, username):
        # Concantenate string to assign the file path based on the user name provided and later send pickled data
        self.filename = "C:\\_PythonClass\\Assignment07\\ConfidenceLeague\\Users\\"+ username
        self.pickedfile = "C:\\_PythonClass\\Assignment07\\ConfidenceLeague\\Users\\" + username + "\\pickedTeams.dat"
        self.unpickedfile = "C:\\_PythonClass\\Assignment07\\ConfidenceLeague\\Users\\" + username + "\\unpickedTeams.dat"
  
    ''' Method to Save Information to Pickle File '''
    def picklesave(self, filein, listin):
        # Create file object based on the filename provided in the 'write binary' mode
        objFile = open(filein,"wb")
        # Write each item from 'listin' to the pickle file
        for item in listin:
            # Writing each item from 'listin' to the file object location 
            pickle.dump(item, objFile)
           # Close the File Object 
        objFile.close()
    ''' Function to Load Pickle Files '''
    def pickleLoad(self, filename):
        # Create an empty list to load the pickled data to ensure it can be unpacked
        returnlist = []
        # Creates the file object 'f' based on the filename provided to the function 
        # in the "read binary" mode.
        with open(filename, "rb") as f:
            # 'while' loop created to ensure each line of the binary code is read 
            while True:
                try:
                    # Appends list to add each of the lines of code read from the file 
                    returnlist.append(pickle.load(f))
                # Exception handler to ensure code does not break once the end of the file
                # has been reached. 
                except EOFError:
                    break
        return returnlist

# List to Store all Available Teams in the NFL
teamList = [
    "cardinals",
    "falcons",
    "ravens",
    "bills",
    "panthers",
    "bears",
    "bengals",
    "browns",
    "cowboys",
    "broncos",
    "lions",
    "packers",
    "texans",
    "colts",
    "jaguars",
    "chiefs",
    "chargers",
    "rams",
    "dolphins",
    "vikings",
    "patriots",
    "saints",
    "giants",
    "jets",
    "raiders",
    "eagles",
    "steelers",
    "niners",
    "seahawks",
    "bucaneers",
    "titans",
    "redskins",
]

# List to Store all the Authorized Users in Survivor League
authorizedUsers = ["kyle", "tory", "ryan", "casey"]

# Empty List for all the unpicked Teams
pickedTeams = []

# Admin Location for raw teams and Authorized Users
teamFile = "C:\\_PythonClass\\Assignment07\\rawTeams.dat"
usersFile = "C:\\_PythonClass\\Assignment07\\rawUsers.dat"

# Begin Main to Create empty Files. Names are stripped of empty characters and put
# made to be lower case to match the file structure. 
nameinput = input('Provide Name to Generate File: ')
nameinput = nameinput.strip()
nameinput = nameinput.lower()

# Instantiate a class
generateData = DataGenerator(nameinput)

# Assign File Paths to variable names based on instantiated Class 
filename = generateData.filename
unpickedfile = generateData.unpickedfile
pickedfile = generateData.pickedfile

# Save raw unpicked Files to user's folder
generateData.picklesave(unpickedfile, teamList)
generateData.picklesave(pickedfile, pickedTeams)

# Ensure Data has been properly stored
unpickedlist = generateData.pickleLoad(unpickedfile)
pickedlist = generateData.pickleLoad(pickedfile)

print(unpickedlist)
print(pickedlist)

input("Press 'Enter' to exit the program")



