#
# Title: A Simple To Do List
# Date: Nov 18, 2018
# Change Log: 
#   KCreek, 11/18/2018, Script Created
#

# Variables

# Assign a file path to the Variable 'filename'
filename = "C:\\_PythonClass\\Assignment05\\Todo.txt"

# Create empty list to store lines written into Dictionaries
tasklist = []


# Functions

# Function to take input from file and create a directory
def dictionarymaker(line):
    # Create an empty dicitonary to store information
    emptydict = {}
    # Splits the input data from the line at the ',' to create a list
    x = line.split(",")
    # Assign variables based on split line to 'task' and 'priority'
    task = x[0].strip()
    priority = x[1].strip()
    # Writes the task and priority to the empty dictionary as a key value pair
    emptydict[task] = priority
    # Return Dictionary
    return emptydict

# Function written to display the dictionaries in a list and assign value
def taskview(listinput):
    linenumber = 0
    # 'for' loop to take each line and perform an action to print out in menu
    for line in listinput:
        for key, value in line.items():
            key = key
            value = value
        print("Task Number: ", linenumber, "\tName: ", key, "\tPriority: ", value)
        linenumber += 1
    return

# Function Written to Add Item to List
def additem(listinput):
    # Create and empty dictionary to store the user input
    emptydict = {}
    # Query User for the name of the task
    task = input("Please Provide the name of the task: ")
    # While loop created to run until priority is obtained
    while True:
        try:
            # Query user for task and direct to appropriate Case Option
            print(''' Please select a Priority of the task
            1 : Low
            2 : Medium
            3 : High
            ''')
            priority = int(input("Please select a priority option: "))
            # Case statement for "Low" priority
            if priority == 1:
                # Stores Task Name and associated priority to the dictionary
                emptydict[task] = 'Low'
                # Appends Dictionary to the list that was input to the function
                listinput.append(emptydict)
                break
            # Case Statement for "Medium" priority
            elif priority == 2:
                 # Stores Task Name and associated priority to the dictionary
                emptydict[task] = 'Medium'
                # Appends Dictionary to the list that was input to the function
                listinput.append(emptydict)
                break
            # Case statement for "High" Priority
            elif priority == 3:
                # Stores Task Name and associated priority to the dictionary
                emptydict[task] = 'High'
                # Appends Dictionary to the list that was input to the function
                listinput.append(emptydict)
                break
            # Case statement for out of range option
            else:
                print("The value provided is out of the range of options")
        except ValueError:
            print("That is not an acceptable option")
    return listinput

# Function written to delete an item from the List
def deleteitem(listinput):
    while True:
        try:
            #Run "taskview" function to give user a list of options to delete
            taskview(listinput)
            # Queries for user input for item to delete
            userChoice = int(input("Select an item from the list to be removed: "))
            del listinput[userChoice]
            break
        except (ValueError, IndexError):
            print("That is not an acceptable option, Please Try again")
    
# Function written to save file based on the file director and data input by user
def filesave(filename, listinput):
    # Creates a file object and opens in write mode
    fileObj = open(filename, 'w')
    # Assigns action for each line in the list input
    for line in listinput:
        # Parses the Key Value Pairing for each of the dictionaries in the provided list
        for key, value in line.items():
            key = key
            value = value
            # Creates a string to write to the file
            text = str(key) + "," + str(value) + "\n"
        fileObj.write(text)
    fileObj.close()


# Main Loop

# Create file object to open file name in 'read' mode.
fileObj = open(filename, 'r')

# 'for' loop to write lines into dictionary and appends them to
# 'emptylist'

for line in fileObj:
    # Makes dicitonary of each line with 'dictionarymaker()' function
    dictionary = dictionarymaker(line)
    # Appends 'tasklist' with the newly made dictionary
    tasklist.append(dictionary)

print("\nHere is your current to do list: ")
taskview(tasklist)

# Begin Main Loop Options Menu
while True:
    
    # Try Statement for error handling
    try:
        # Prints Users options
        print('''
        Please select an action to perform:
        1. Show Current "To Do" List
        2. Add new item(s) to "To Do" List
        3. Remove an existing item from "To Do" List
        4. Save Data to "To Do" List
        5. Exit Program
        ''')
        userInput = int(input("Please select option from the Table: "))

        # Case STatement to Read "To Do" List
        if userInput == 1:
            taskview(tasklist)
        
        # Case Statement to Add Item to "To Do" List
        elif userInput == 2:
            tasklist = additem(tasklist)
        
        # Case Statement to Remove and item from "To Do" List
        elif userInput == 3:
            deleteitem(tasklist)
        
        # Case Statement to Save data to file
        elif userInput == 4:
            filesave(filename, tasklist)

        elif userInput == 5:
            print("\nClosing Program")
            break

        else:
            print('That is not within the range of accetpable options')
    except ValueError:
        print('That is not a valid response')

input("Press 'Enter' to close Window")



